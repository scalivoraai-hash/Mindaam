import math
import time
from fastapi import APIRouter, Depends, HTTPException
from pydantic import Field
from sqlalchemy import select, func, or_, and_
from .db import get_db, APP_ENV
from .models import *
from .auth import current_user
from .economy import credit, config, balance
from .core import Strict, check_city, CITIES, emit, serialize

router = APIRouter(prefix="/api")


class CityInput(Strict):
    city: str


class Movement(Strict):
    dx: float = Field(ge=-1, le=1, allow_inf_nan=False)
    dz: float = Field(ge=-1, le=1, allow_inf_nan=False)
    mode: str = "walk"


def blocked(db, a, b):
    return (
        db.scalar(
            select(Social.id).where(
                Social.kind == "block",
                or_(
                    and_(Social.actor == a, Social.target == b),
                    and_(Social.actor == b, Social.target == a),
                ),
            )
        )
        is not None
    )


def friends(db, a, b):
    return (
        db.scalar(
            select(Social.id).where(
                Social.kind == "friend", Social.actor == a, Social.target == b
            )
        )
        is not None
    )


def visible(db, viewer, target, p, pviewer):
    if (
        blocked(db, viewer.id, target.id)
        or target.privacy == "Ghost Mode"
        or target.suspended
    ):
        return False
    if target.privacy == "Friends Only" and not friends(db, viewer.id, target.id):
        return False
    if target.privacy == "Event Mode":
        return False  # fail closed until shared-event presence exists
    if (
        target.privacy == "Zone Mode"
        and math.hypot(p.x - pviewer.x, p.z - pviewer.z) > 60
    ):
        return False
    return math.hypot(p.x - pviewer.x, p.z - pviewer.z) <= 180


def snapshot(db, u, city):
    check_city(city)
    own = db.get(Presence, u.id)
    if not own or own.city != city:
        raise HTTPException(409, "Enter this city first")
    own.updated_at = time.time()
    claimed = select(Claim.collectible_id).where(Claim.user_id == u.id)
    objects = db.scalars(
        select(Collectible).where(
            Collectible.city == city,
            Collectible.active == True,
            Collectible.starts_at <= time.time(),
            Collectible.ends_at > time.time(),
            Collectible.claims < Collectible.max_claims,
            ~Collectible.id.in_(claimed),
        )
    ).all()
    players = []
    for p, target in db.execute(
        select(Presence, User)
        .join(User, User.id == Presence.user_id)
        .where(
            Presence.city == city,
            Presence.updated_at > time.time() - 45,
            Presence.user_id != u.id,
        )
    ):
        if visible(db, u, target, p, own):
            players.append(
                {
                    "id": target.id,
                    "username": target.username,
                    "avatar": target.avatar,
                    "x": p.x,
                    "z": p.z,
                    "mode": p.mode,
                }
            )
    return {
        "city": city,
        "zone": next(c["zone"] for c in CITIES if c["id"] == city),
        "position": {"x": own.x, "z": own.z, "mode": own.mode},
        "collectibles": [
            serialize(c) for c in objects if math.hypot(c.x - own.x, c.z - own.z) < 200
        ],
        "players": players,
        "businesses": [],
        "online": len(players) + 1,
        "simulated": True,
    }


@router.post("/world/enter")
def enter(data: CityInput, u=Depends(current_user), db=Depends(get_db)):
    check_city(data.city)
    if not u.onboarded:
        raise HTTPException(409, "Complete onboarding")
    p = db.get(Presence, u.id)
    if not p:
        db.add(Presence(user_id=u.id, city=data.city, x=0, z=0))
    elif p.city != data.city:
        p.city = data.city
        p.x = 0
        p.z = 0
        p.mode = "walk"
        p.last_move = time.time()
    from .discovery import record_stamp

    record_stamp(db, u.id, data.city)
    u.city = data.city
    db.flush()
    emit(db, u, "city_entered", data.city)
    return snapshot(db, u, data.city)


@router.get("/world/{city}")
def world(city: str, u=Depends(current_user), db=Depends(get_db)):
    return snapshot(db, u, city)


@router.post("/world/move")
def move(data: Movement, u=Depends(current_user), db=Depends(get_db)):
    p = db.scalar(select(Presence).where(Presence.user_id == u.id).with_for_update())
    if not p:
        raise HTTPException(409, "Enter world first")
    speeds = {"walk": 6, "run": 10, "bike": 15, "scooter": 18, "car": 25}
    if data.mode not in speeds:
        raise HTTPException(422, "Unsupported movement mode")
    if data.mode not in {"walk", "run"}:
        e = db.get(Entitlement, (u.id, data.mode))
        if not e or e.expires_at < time.time():
            raise HTTPException(403, "Rent or unlock this vehicle first")
    now = time.time()
    dt = min(max(now - p.last_move, 0), 0.3)
    length = max(1, math.hypot(data.dx, data.dz))
    x = p.x + data.dx / length * speeds[data.mode] * dt
    z = p.z + data.dz / length * speeds[data.mode] * dt
    # Local adapter uses a plus-shaped walkable district; buildings are outside streets.
    if abs(x) <= 14 or abs(z) <= 14:
        p.x = max(-180, min(180, x))
        p.z = max(-180, min(180, z))
    p.mode = data.mode
    p.last_move = now
    p.updated_at = now
    return {"x": p.x, "z": p.z, "mode": p.mode}


def mission_views(db, u):
    counts = dict(
        db.execute(
            select(Collectible.kind, func.count(Claim.id))
            .join(Claim, Claim.collectible_id == Collectible.id)
            .where(Claim.user_id == u.id, Collectible.city == u.city)
            .group_by(Collectible.kind)
        ).all()
    )
    done = set(
        db.scalars(
            select(MissionCompletion.mission_id).where(
                MissionCompletion.user_id == u.id
            )
        )
    )
    return [
        {
            **serialize(m),
            "progress": {
                k: min(counts.get(k, 0), v) for k, v in m.requirements.items()
            },
            "completed": m.id in done,
            "eligible": all(counts.get(k, 0) >= v for k, v in m.requirements.items()),
        }
        for m in db.scalars(select(Mission).where(Mission.city == u.city))
    ]


@router.get("/missions")
def missions(u=Depends(current_user), db=Depends(get_db)):
    return mission_views(db, u)


@router.post("/collectibles/{object_id}/claim")
def collect(object_id: str, u=Depends(current_user), db=Depends(get_db)):
    db.scalar(select(User).where(User.id == u.id).with_for_update())
    c = db.scalar(
        select(Collectible).where(Collectible.id == object_id).with_for_update()
    )
    p = db.get(Presence, u.id)
    if not c:
        raise HTTPException(404, "Collectible not found")
    existing = db.scalar(
        select(Claim).where(Claim.user_id == u.id, Claim.collectible_id == object_id)
    )
    if existing:
        return {
            "claimed": True,
            "already_claimed": True,
            "credits": balance(db, u.id),
            "xp": balance(db, u.id, "xp"),
            "missions": mission_views(db, u),
        }
    now = time.time()
    if not c.active or not c.starts_at <= now < c.ends_at or c.claims >= c.max_claims:
        raise HTTPException(409, "This collectible is no longer available")
    if (
        not p
        or p.city != c.city
        or p.updated_at < now - 45
        or math.hypot(p.x - c.x, p.z - c.z) > 5
    ):
        raise HTTPException(409, "Move closer to collect this item")
    db.add(Claim(user_id=u.id, collectible_id=c.id))
    c.claims += 1
    credit(
        db,
        u.id,
        5 if c.kind == "fruit" else 15,
        "collectible",
        c.id,
        "collect:" + c.id,
        currency="xp",
    )
    db.flush()
    emit(db, u, c.kind + "_collected", c.id)
    for m in mission_views(db, u):
        if m["eligible"] and not m["completed"]:
            db.add(MissionCompletion(user_id=u.id, mission_id=m["id"]))
            credit(db, u.id, m["credits"], "mission", m["id"], "mission:" + m["id"])
            credit(
                db,
                u.id,
                m["xp"],
                "mission",
                m["id"],
                "mission:" + m["id"],
                currency="xp",
            )
            db.flush()
            emit(db, u, "mission_completed", m["id"])
            r = db.get(Referral, u.id)
            if r and not r.rewarded and u.verified:
                parent = db.get(User, r.referrer_id)
                if parent and not parent.suspended:
                    credit(db, parent.id, 20, "referral", u.id, "referral:" + u.id)
                    r.rewarded = True
    return {
        "claimed": True,
        "credits": balance(db, u.id),
        "xp": balance(db, u.id, "xp"),
        "missions": mission_views(db, u),
    }


class Rental(Strict):
    mode: str


@router.post("/transport/rent")
def rent(data: Rental, u=Depends(current_user), db=Depends(get_db)):
    if data.mode not in {"bike", "scooter", "car"}:
        raise HTTPException(422, "Unavailable vehicle")
    db.scalar(select(User).where(User.id == u.id).with_for_update())
    old = db.get(Entitlement, (u.id, data.mode))
    if old and old.expires_at > time.time():
        return serialize(old)
    price = config(db, "vehicle_prices", {"bike": 10, "scooter": 20, "car": 30})[
        data.mode
    ]
    expiry = time.time() + 3600
    credit(db, u.id, -price, "vehicle_rental", data.mode, "rent:" + uid())
    if old:
        old.expires_at = expiry
    else:
        old = Entitlement(user_id=u.id, kind=data.mode, expires_at=expiry)
        db.add(old)
    db.flush()
    return serialize(old)


@router.get("/leaderboard")
def leaderboard(u=Depends(current_user), db=Depends(get_db)):
    rows = db.execute(
        select(User, func.sum(Ledger.amount).label("xp"))
        .join(Ledger, Ledger.user_id == User.id)
        .where(
            Ledger.currency == "xp",
            User.suspended == False,
            User.privacy != "Ghost Mode",
        )
        .group_by(User.id)
        .order_by(func.sum(Ledger.amount).desc())
        .limit(50)
    ).all()
    return [
        {
            "id": p.id,
            "username": p.username,
            "city": p.city,
            "xp": xp,
            "avatar": p.avatar,
        }
        for p, xp in rows
        if not blocked(db, u.id, p.id)
    ]
