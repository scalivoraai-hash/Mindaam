import time
from fastapi import APIRouter, Depends, HTTPException
from pydantic import Field
from sqlalchemy import select, or_, and_, func, delete
from .db import get_db
from .models import *
from .auth import current_user
from .core import Strict, serialize, notify, emit, check_city
from .world import blocked, friends

router = APIRouter(prefix="/api")


def target_user(db, u, user_id):
    p = db.get(User, user_id)
    if not p or p.suspended or p.id == u.id:
        raise HTTPException(404, "Player unavailable")
    return p


@router.get("/people")
def people(u=Depends(current_user), db=Depends(get_db)):
    results = []
    for p in db.scalars(
        select(User)
        .where(User.id != u.id, User.suspended == False, User.onboarded == True)
        .limit(200)
    ):
        if blocked(db, u.id, p.id) or p.privacy in {"Ghost Mode", "Event Mode"}:
            continue
        if p.privacy == "Friends Only" and not friends(db, u.id, p.id):
            continue
        outgoing = db.scalars(
            select(Social.kind).where(Social.actor == u.id, Social.target == p.id)
        ).all()
        incoming = db.scalars(
            select(Social.kind).where(Social.actor == p.id, Social.target == u.id)
        ).all()
        presence = db.get(Presence, p.id)
        results.append(
            {
                "id": p.id,
                "username": p.username,
                "avatar": p.avatar,
                "city": p.city,
                "friend": friends(db, u.id, p.id),
                "following": "follow" in outgoing,
                "requested": "request" in outgoing,
                "incoming": "request" in incoming,
                "online": bool(presence and presence.updated_at > time.time() - 45),
            }
        )
    return results


@router.post("/social/{user_id}/{action}")
async def social_action(
    user_id: str, action: str, u=Depends(current_user), db=Depends(get_db)
):
    p = target_user(db, u, user_id)
    if action not in {"wave", "follow", "friend", "accept", "block", "unblock", "mute"}:
        raise HTTPException(422, "Unknown social action")
    if action == "unblock":
        db.execute(
            delete(Social).where(
                Social.actor == u.id, Social.target == p.id, Social.kind == "block"
            )
        )
        return {"ok": True}
    if action != "block" and blocked(db, u.id, p.id):
        raise HTTPException(403, "Interaction unavailable")
    if action == "wave":
        notify(db, p.id, "wave", u.username + " waved at you", u.id)
        emit(db, u, "wave_sent", p.id)
        return {"ok": True}
    kind = {"friend": "request", "accept": "friend"}.get(action, action)
    if action == "accept":
        request = db.scalar(
            select(Social).where(
                Social.actor == p.id, Social.target == u.id, Social.kind == "request"
            )
        )
        if not request:
            raise HTTPException(409, "No incoming request")
        db.delete(request)
        if not friends(db, p.id, u.id):
            db.add(Social(actor=p.id, target=u.id, kind="friend"))
    if not db.scalar(
        select(Social).where(
            Social.actor == u.id, Social.target == p.id, Social.kind == kind
        )
    ):
        db.add(Social(actor=u.id, target=p.id, kind=kind))
    if action == "block":
        for s in db.scalars(
            select(MediaSession).where(
                or_(
                    and_(MediaSession.requester == u.id, MediaSession.target == p.id),
                    and_(MediaSession.requester == p.id, MediaSession.target == u.id),
                ),
                MediaSession.state.in_(["pending", "accepted"]),
            )
        ):
            from .media import terminate_room

            if s.state == "accepted":
                await terminate_room(s.id)
            s.state = "ended"
            s.ended_at = time.time()
        db.add(Audit(actor_id=u.id, action="social.block", target=p.id))
    else:
        notify(db, p.id, action, u.username + " sent a " + action, u.id)
    return {"ok": True}


class MessageInput(Strict):
    body: str = Field(min_length=1, max_length=2000)


@router.get("/messages/{user_id}")
def messages(user_id: str, u=Depends(current_user), db=Depends(get_db)):
    target_user(db, u, user_id)
    if blocked(db, u.id, user_id):
        raise HTTPException(403, "Conversation unavailable")
    rows = db.scalars(
        select(Message)
        .where(
            or_(
                and_(Message.sender == u.id, Message.recipient == user_id),
                and_(Message.sender == user_id, Message.recipient == u.id),
            )
        )
        .order_by(Message.created_at.desc())
        .limit(100)
    ).all()
    for m in rows:
        if m.recipient == u.id:
            m.read = True
    return [serialize(m) for m in reversed(rows)]


@router.post("/messages/{user_id}", status_code=201)
def send_message(
    user_id: str, data: MessageInput, u=Depends(current_user), db=Depends(get_db)
):
    target_user(db, u, user_id)
    if blocked(db, u.id, user_id):
        raise HTTPException(403, "Conversation unavailable")
    if not data.body.strip():
        raise HTTPException(422, "Message cannot be empty")
    m = Message(sender=u.id, recipient=user_id, body=data.body.strip())
    db.add(m)
    db.flush()
    emit(db, u, "message_sent", m.id)
    notify(db, user_id, "message", u.username + " sent a message", u.id)
    return serialize(m)


class CrewInput(Strict):
    name: str = Field(min_length=3, max_length=80)
    description: str = Field(default="", max_length=500)
    city: str = "london"
    private: bool = False


@router.get("/crews")
def crews(u=Depends(current_user), db=Depends(get_db)):
    rows = []
    for c in db.scalars(select(Crew).limit(100)):
        joined = db.get(CrewMember, (c.id, u.id)) is not None
        if (c.private and not joined) or blocked(db, u.id, c.owner_id):
            continue
        rows.append(
            {
                **serialize(c),
                "joined": joined,
                "members": db.scalar(
                    select(func.count())
                    .select_from(CrewMember)
                    .where(CrewMember.crew_id == c.id)
                ),
            }
        )
    return rows


@router.post("/crews", status_code=201)
def create_crew(data: CrewInput, u=Depends(current_user), db=Depends(get_db)):
    check_city(data.city)
    if db.scalar(select(Crew.id).where(Crew.name == data.name)):
        raise HTTPException(409, "Crew name taken")
    c = Crew(**data.model_dump(), owner_id=u.id)
    db.add(c)
    db.flush()
    db.add(CrewMember(crew_id=c.id, user_id=u.id, role="owner"))
    return serialize(c)


@router.post("/crews/{crew_id}/join")
def join_crew(crew_id: str, u=Depends(current_user), db=Depends(get_db)):
    c = db.scalar(select(Crew).where(Crew.id == crew_id).with_for_update())
    if not c or c.private or blocked(db, u.id, c.owner_id):
        raise HTTPException(404, "Open Crew not found")
    if not db.get(CrewMember, (crew_id, u.id)):
        db.add(CrewMember(crew_id=crew_id, user_id=u.id))
        emit(db, u, "crew_joined", crew_id)
    return {"ok": True}


class EventInput(Strict):
    title: str = Field(min_length=3, max_length=120)
    description: str = Field(default="", max_length=1000)
    city: str
    starts_at: float = Field(allow_inf_nan=False)
    capacity: int = Field(default=100, ge=2, le=10000)


@router.get("/events")
def events(u=Depends(current_user), db=Depends(get_db)):
    return [
        {
            **serialize(e),
            "joined": db.get(Attendee, (e.id, u.id)) is not None,
            "attendees": db.scalar(
                select(func.count())
                .select_from(Attendee)
                .where(Attendee.event_id == e.id)
            ),
        }
        for e in db.scalars(
            select(Event)
            .where(Event.starts_at > time.time() - 3600)
            .order_by(Event.starts_at)
            .limit(100)
        )
        if not blocked(db, u.id, e.host_id)
    ]


@router.post("/events", status_code=201)
def create_event(data: EventInput, u=Depends(current_user), db=Depends(get_db)):
    check_city(data.city)
    if data.starts_at < time.time():
        raise HTTPException(422, "Choose a future date")
    e = Event(**data.model_dump(), host_id=u.id)
    db.add(e)
    db.flush()
    return serialize(e)


@router.post("/events/{event_id}/join")
def join_event(event_id: str, u=Depends(current_user), db=Depends(get_db)):
    e = db.scalar(select(Event).where(Event.id == event_id).with_for_update())
    if not e or blocked(db, u.id, e.host_id) or e.starts_at < time.time() - 3600:
        raise HTTPException(404, "Event unavailable")
    if db.get(Attendee, (event_id, u.id)):
        return {"ok": True}
    count = db.scalar(
        select(func.count()).select_from(Attendee).where(Attendee.event_id == event_id)
    )
    if count >= e.capacity:
        raise HTTPException(409, "Event is full")
    db.add(Attendee(event_id=event_id, user_id=u.id))
    emit(db, u, "event_joined", event_id)
    return {"ok": True}


class ReportInput(Strict):
    target_id: str
    category: str = Field(min_length=3, max_length=40)
    details: str = Field(min_length=5, max_length=2000)


@router.post("/reports", status_code=201)
def report(data: ReportInput, u=Depends(current_user), db=Depends(get_db)):
    target_user(db, u, data.target_id)
    r = Report(**data.model_dump(), reporter_id=u.id)
    db.add(r)
    db.flush()
    return {"id": r.id, "status": r.status}
