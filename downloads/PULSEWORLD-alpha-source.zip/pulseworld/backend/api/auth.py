import hashlib
import secrets
import time
import bcrypt
from fastapi import Depends, HTTPException, Header
from sqlalchemy import select
from .db import get_db
from .models import User, Session


def hash_password(password):
    return bcrypt.hashpw(
        hashlib.sha256(password.encode()).digest(), bcrypt.gensalt(rounds=12)
    ).decode()


def check_password(password, hashed):
    return bcrypt.checkpw(hashlib.sha256(password.encode()).digest(), hashed.encode())


def session_token(db, user):
    token = secrets.token_urlsafe(40)
    db.add(
        Session(
            id=hashlib.sha256(token.encode()).hexdigest(),
            user_id=user.id,
            expires_at=time.time() + 86400,
        )
    )
    return token


def user_for_token(db, token):
    s = db.get(Session, hashlib.sha256(token.encode()).hexdigest())
    if not s or s.expires_at < time.time():
        raise HTTPException(401, "Session expired. Please sign in.")
    u = db.get(User, s.user_id)
    if not u or u.suspended:
        raise HTTPException(403, "Account unavailable")
    return u


def current_user(authorization: str = Header(default=""), db=Depends(get_db)):
    if not authorization.startswith("Bearer "):
        raise HTTPException(401, "Please sign in")
    return user_for_token(db, authorization[7:])


def require_admin(user=Depends(current_user)):
    if user.role not in {"admin", "super_admin"}:
        raise HTTPException(403, "Administrator access required")
    return user


def public_user(u):
    return {
        k: getattr(u, k)
        for k in (
            "id",
            "email",
            "verified",
            "username",
            "city",
            "avatar",
            "privacy",
            "interests",
            "onboarded",
            "role",
            "location_consent",
            "analytics_consent",
        )
    }
