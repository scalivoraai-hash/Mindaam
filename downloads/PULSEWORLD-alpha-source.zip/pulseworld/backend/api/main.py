import asyncio
import os
import time
from contextlib import asynccontextmanager
from collections import defaultdict, deque
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Request
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import text, select, delete, or_
from sqlalchemy.exc import IntegrityError
from .db import engine, SessionLocal, APP_ENV
from . import (
    core,
    world,
    social,
    media,
    commerce,
    identity,
    discovery,
    gameplay,
    subscriptions,
)
from .auth import user_for_token
from .models import Presence, Notification, MediaSession, Session, User
from .core import serialize


async def cleanup():
    while True:
        await asyncio.sleep(15)
        try:
            with SessionLocal.begin() as db:
                db.execute(
                    delete(Presence).where(Presence.updated_at < time.time() - 60)
                )
                db.execute(delete(Session).where(Session.expires_at < time.time()))
                active = db.scalars(
                    select(MediaSession).where(MediaSession.state == "accepted")
                ).all()
                for s in active:
                    requester = db.get(User, s.requester)
                    target = db.get(User, s.target)
                    if (
                        not requester
                        or not target
                        or requester.suspended
                        or target.suspended
                        or world.blocked(db, s.requester, s.target)
                        or not s.accepted_at
                        or s.accepted_at < time.time() - 600
                    ):
                        await media.terminate_room(s.id)
                        s.state = "ended"
                        s.ended_at = time.time()
        except Exception:
            import logging

            logging.getLogger("pulseworld").exception("Maintenance failed")


@asynccontextmanager
async def lifespan(app):
    task = asyncio.create_task(cleanup())
    yield
    task.cancel()
    try:
        await task
    except asyncio.CancelledError:
        pass


app = FastAPI(title="PULSEWORLD API", version="0.1.0-alpha", lifespan=lifespan)
for route in [
    core.router,
    world.router,
    social.router,
    media.router,
    commerce.router,
    identity.router,
    discovery.router,
    gameplay.router,
    subscriptions.router,
]:
    app.include_router(route)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[os.getenv("PUBLIC_ORIGIN", "http://localhost:3000")],
    allow_credentials=False,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
    allow_headers=["Authorization", "Content-Type", "Idempotency-Key"],
)
local_buckets = defaultdict(deque)
redis_client = None
if os.getenv("REDIS_URL"):
    import redis

    redis_client = redis.Redis.from_url(
        os.environ["REDIS_URL"], socket_connect_timeout=1, socket_timeout=1
    )
if APP_ENV in {"staging", "production"} and not redis_client:
    raise RuntimeError("Redis required outside local/test")


@app.middleware("http")
async def security(request: Request, call_next):
    try:
        declared_size = int(request.headers.get("content-length", "0") or 0)
    except ValueError:
        return JSONResponse({"detail": "Invalid content length"}, 400)
    if declared_size < 0:
        return JSONResponse({"detail": "Invalid content length"}, 400)
    if declared_size > 262144:
        return JSONResponse({"detail": "Request too large"}, 413)
    if request.method in {"POST", "PUT", "PATCH"}:
        body = bytearray()
        async for chunk in request.stream():
            if len(body) + len(chunk) > 262144:
                return JSONResponse({"detail": "Request too large"}, 413)
            body.extend(chunk)
        request._body = bytes(body)
    if request.url.path not in {"/health", "/ready", "/api/payments/webhook"}:
        ip = request.client.host if request.client else "unknown"
        sensitive = request.url.path.startswith("/api/auth")
        limit = 20 if sensitive else 1200
        window = 60
        key = ("auth:" if sensitive else "api:") + ip
        try:
            if redis_client:
                tick = int(time.time() // window)
                rkey = "rate:" + key + ":" + str(tick)
                count = redis_client.eval(
                    "local n=redis.call('INCR',KEYS[1]); if n==1 then redis.call('EXPIRE',KEYS[1],ARGV[1]) end; return n",
                    1,
                    rkey,
                    window,
                )
            else:
                q = local_buckets[key]
                now = time.time()
                while q and q[0] < now - window:
                    q.popleft()
                q.append(now)
                count = len(q)
            if count > limit:
                return JSONResponse(
                    {"detail": "Too many requests. Retry shortly."},
                    429,
                    headers={"Retry-After": "60"},
                )
        except Exception:
            return JSONResponse(
                {"detail": "Rate-limit service unavailable. Retry shortly."}, 503
            )
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "same-origin"
    response.headers["Cache-Control"] = "no-store"
    return response


@app.exception_handler(IntegrityError)
async def conflict(request, exc):
    return JSONResponse(
        {
            "detail": "This operation conflicts with an existing record. Refresh and retry."
        },
        status_code=409,
    )


@app.get("/health")
def health():
    return {"status": "ok", "version": "0.1.0-alpha"}


@app.get("/ready")
def ready():
    try:
        with engine.connect() as c:
            c.execute(text("SELECT 1 FROM users LIMIT 1"))
        if redis_client:
            redis_client.ping()
    except Exception:
        raise HTTPException(503, "Database/migrations or Redis unavailable")
    return {"status": "ready", "environment": APP_ENV, "release_ready": False}


@app.websocket("/api/realtime")
async def realtime(socket: WebSocket):
    origin = socket.headers.get("origin")
    if origin and origin != os.getenv("PUBLIC_ORIGIN", "http://localhost:3000"):
        await socket.close(code=4403)
        return
    await socket.accept()
    try:
        initial = await asyncio.wait_for(socket.receive_json(), timeout=5)
        token = initial.get("token", "")
        if not isinstance(token, str) or len(token) > 256:
            raise HTTPException(401, "Invalid session")
        while True:
            with SessionLocal.begin() as db:
                u = user_for_token(db, token)
                p = db.get(Presence, u.id)
                result = (
                    world.snapshot(db, u, p.city)
                    if p
                    else {"players": [], "collectibles": []}
                )
                result["type"] = "state"
                result["notifications"] = [
                    serialize(n)
                    for n in db.scalars(
                        select(Notification)
                        .where(
                            Notification.user_id == u.id,
                            Notification.created_at > time.time() - 120,
                        )
                        .order_by(Notification.created_at.desc())
                        .limit(20)
                    )
                ]
                result["media"] = [
                    serialize(s)
                    for s in db.scalars(
                        select(MediaSession).where(
                            or_(
                                MediaSession.requester == u.id,
                                MediaSession.target == u.id,
                            ),
                            MediaSession.state.in_(["pending", "accepted"]),
                            MediaSession.created_at > time.time() - 900,
                        )
                    )
                    if not world.blocked(db, s.requester, s.target)
                ]
                if redis_client:
                    redis_client.setex(
                        "presence:" + u.id,
                        45,
                        str(
                            {"city": u.city, "x": p.x if p else 0, "z": p.z if p else 0}
                        ),
                    )
            await socket.send_json(result)
            await asyncio.sleep(0.5)
    except (WebSocketDisconnect, asyncio.TimeoutError):
        pass
    except HTTPException:
        await socket.close(code=4401)
    except Exception:
        try:
            await socket.close(code=1011)
        except Exception:
            pass
