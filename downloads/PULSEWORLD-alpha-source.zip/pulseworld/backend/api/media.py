import os
import time
from datetime import timedelta
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select, or_, and_
from .db import get_db
from .models import MediaSession, User
from .auth import current_user
from .core import Strict, serialize, notify, emit
from .world import blocked

router = APIRouter(prefix="/api")


class MediaRequest(Strict):
    target_id: str
    kind: str


def provider_ready():
    return all(
        os.getenv(k) for k in ["LIVEKIT_URL", "LIVEKIT_API_KEY", "LIVEKIT_API_SECRET"]
    )


def get_session(db, u, id):
    s = db.scalar(select(MediaSession).where(MediaSession.id == id).with_for_update())
    if not s or u.id not in {s.requester, s.target}:
        raise HTTPException(404, "Media session unavailable")
    return s


@router.get("/media")
def sessions(u=Depends(current_user), db=Depends(get_db)):
    rows = db.scalars(
        select(MediaSession).where(
            or_(MediaSession.requester == u.id, MediaSession.target == u.id),
            MediaSession.state.in_(["pending", "accepted"]),
            MediaSession.created_at > time.time() - 900,
        )
    ).all()
    return [serialize(s) for s in rows if not blocked(db, s.requester, s.target)]


@router.post("/media/request")
def request_media(data: MediaRequest, u=Depends(current_user), db=Depends(get_db)):
    if data.kind not in {"voice", "liveface"}:
        raise HTTPException(422, "Unknown media kind")
    p = db.get(User, data.target_id)
    if not p or p.suspended or p.id == u.id:
        raise HTTPException(404, "Player unavailable")
    if blocked(db, u.id, p.id):
        raise HTTPException(403, "Interaction unavailable")
    # Consent workflow can be tested without enabling any device or minting a token.
    pending = db.scalar(
        select(MediaSession).where(
            MediaSession.requester == u.id,
            MediaSession.target == p.id,
            MediaSession.state.in_(["pending", "accepted"]),
            MediaSession.created_at > time.time() - 600,
        )
    )
    if pending:
        return serialize(pending)
    s = MediaSession(requester=u.id, target=p.id, kind=data.kind)
    db.add(s)
    db.flush()
    notify(
        db, p.id, data.kind + "_request", u.username + " requests " + data.kind, s.id
    )
    emit(db, u, data.kind + "_requested", s.id)
    return serialize(s)


@router.post("/media/{session_id}/accept")
def accept(session_id: str, u=Depends(current_user), db=Depends(get_db)):
    s = get_session(db, u, session_id)
    if u.id != s.target:
        raise HTTPException(403, "Only the invited player can consent")
    if blocked(db, s.requester, s.target) or any(
        not (peer := db.get(User, user_id)) or peer.suspended
        for user_id in (s.requester, s.target)
    ):
        raise HTTPException(403, "Interaction unavailable")
    if s.created_at < time.time() - 120:
        raise HTTPException(409, "Request expired")
    if s.state != "pending":
        raise HTTPException(409, "Request is no longer pending")
    s.state = "accepted"
    s.accepted_at = time.time()
    notify(
        db, s.requester, "media_accepted", u.username + " accepted your request", s.id
    )
    return {**serialize(s), "provider_ready": provider_ready()}


@router.post("/media/{session_id}/reject")
def reject(session_id: str, u=Depends(current_user), db=Depends(get_db)):
    s = get_session(db, u, session_id)
    if s.state != "pending":
        raise HTTPException(409, "Request no longer pending")
    s.state = "rejected"
    s.ended_at = time.time()
    return serialize(s)


async def terminate_room(id):
    if not provider_ready():
        return
    from livekit import api

    async with api.LiveKitAPI(
        os.environ["LIVEKIT_URL"],
        os.environ["LIVEKIT_API_KEY"],
        os.environ["LIVEKIT_API_SECRET"],
    ) as client:
        try:
            await client.room.delete_room(api.DeleteRoomRequest(room="pulse-" + id))
        except api.TwirpError as e:
            if e.code != "not_found":
                raise HTTPException(
                    502,
                    "Video provider unavailable. Disable your camera and microphone; retry disconnect.",
                )


@router.post("/media/{session_id}/end")
async def end(session_id: str, u=Depends(current_user), db=Depends(get_db)):
    s = get_session(db, u, session_id)
    if s.state == "accepted":
        await terminate_room(s.id)
    s.state = "ended"
    s.ended_at = time.time()
    return serialize(s)


@router.post("/media/{session_id}/token")
def token(session_id: str, u=Depends(current_user), db=Depends(get_db)):
    from livekit import api

    s = get_session(db, u, session_id)
    if (
        s.state != "accepted"
        or blocked(db, s.requester, s.target)
        or any(
            not (peer := db.get(User, user_id)) or peer.suspended
            for user_id in (s.requester, s.target)
        )
    ):
        raise HTTPException(403, "Mutual consent required")
    if not s.accepted_at or time.time() - s.accepted_at > 600:
        raise HTTPException(409, "Session allowance expired")
    if not provider_ready():
        raise HTTPException(
            503,
            "LiveKit is not configured. No camera or microphone access has been requested.",
        )
    # Room-scoped grant and short join expiry. Server maintenance revokes the room at session deadline.
    t = (
        api.AccessToken(os.environ["LIVEKIT_API_KEY"], os.environ["LIVEKIT_API_SECRET"])
        .with_identity(u.id)
        .with_name(u.username)
        .with_ttl(timedelta(seconds=60))
        .with_grants(
            api.VideoGrants(
                room_join=True,
                room="pulse-" + s.id,
                can_publish=True,
                can_subscribe=True,
                can_publish_sources=["microphone"]
                if s.kind == "voice"
                else ["camera", "microphone"],
            )
        )
    )
    return {
        "token": t.to_jwt(),
        "url": os.environ["LIVEKIT_URL"],
        "room": "pulse-" + s.id,
        "kind": s.kind,
        "expires_at": s.accepted_at + 600,
    }
