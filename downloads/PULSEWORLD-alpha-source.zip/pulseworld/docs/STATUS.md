# Release status — 2026-09-13

**Testable alpha source. Not certified production-ready and not publicly deployed.**

## Implemented

- Next.js consumer app, merchant and admin portals; public `/explore` simulated city preview, Three.js scene and 2D fallback.
- Account registration, login, onboarding, password reset/email verification plumbing, session revocation and consent.
- Server-authoritative movement, collectible claims, missions, daily rewards and immutable Credits/XP accounting.
- Friends, blocking, direct messages, Crews, invitations, events, notifications and CityBattles.
- Merchant onboarding/verification, catalogues, campaign funding, signed single-use PulsePoints, redemption and analytics.
- Stripe checkout and recurring billing integration with signed/idempotent webhook handling; LiveKit consent/session integration. Live providers remain unvalidated.
- Privacy export/anonymization, moderation, audit and configuration endpoints.
- Versioned migrations, PostgreSQL/PostGIS and Redis deployment configuration, unified Railway Docker image and CI definitions.

## Validation evidence

`npm run build` passed on 2026-09-13, including TypeScript checks and generation of all 11 static pages. The backend suite passed before the final public-preview privacy regression was added; the consolidated JUnit report bundled under `validation-artifacts/pytest.xml` records the final suite. Tests cover transactional/idempotent rewards, authorization, signed payment events, privacy and clean SQLite migration application with database-level immutable ledger checks. Passing local tests is not proof of production correctness.

## Remaining release work

- Publish source to a user-confirmed GitHub repository connected to Railway; no Railway projects or source remote existed at the last check.
- Build the Docker image on the target platform and validate durable PostGIS/Redis, HTTPS, migrations, restarts, backups and recovery.
- Complete real two-user browser and mobile journeys, provider sandbox payments/subscriptions, SMTP delivery and consent-based audio/video tests.
- Complete security/privacy review, operational ownership, legal-policy approval, accessibility and measured performance/load gates.
- Licensed real-map integration, broad world fidelity, production campaign content, advanced commerce/refunds, fully metered media entitlements and other unfinished specification requirements remain roadmap work.

Procedural scenes are explicitly simulated. No seeded fake users, merchant activity or payment success. Optional integrations fail closed without configuration. The full 120-section specification is retained in PRODUCT.md; this implementation does not claim full specification completion. See RELEASE_CHECKLIST.md for outstanding acceptance gates.
