import type { Metadata } from 'next';
import './globals.css';import ServiceWorker from '@/components/ServiceWorker';
export const metadata:Metadata={title:'PULSEWORLD · Your City. Alive.',manifest:'/manifest.webmanifest',icons:{icon:'/icon.svg',apple:'/icon-192.png'},description:'Explore a shared city, meet people and discover local rewards.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body><ServiceWorker/>{children}</body></html>}
